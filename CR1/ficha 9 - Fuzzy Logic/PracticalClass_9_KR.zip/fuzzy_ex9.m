function [ fis_tip ] = fuzzy_ex9()

%STEP 1: create the FIS structure named fis_tip
%TO COMPLETE


% STEP 2: Create linguistic variables ‘service’, ‘food’ and ‘tip’
fis_tip=addvar(fis_tip,'input',service,[0 10]);
%COMPLETE

% STEP 3: membership functions for each variable created previously
fis_tip =addmf(fis_tip,'input',1,'weak','gaussmf',[1.5 0]);
%COMPLETE

fis_tip =addmf(fis_tip,'input',2,'bad','trapmf',[0 0 1 3]);
%COMPLETE
 
fis_tip =addmf(fis_tip,'output',1,'weak','trimf',[0 5 10]);
%COMPLETE
 
% STEP 4: create rules matrix and add with addrule

rules=[];%COMPLETE



% STEP 5: evaluate for various values ​​of service and food with evalfis
for service=0:10
	for food=0:10
        	input=[service food];
        	out = evalfis(input,fis_tip);
        	fprintf('service = %d\nfood = %d\ntip = %f\n\n',service, food, out);
	end
end
 
end
