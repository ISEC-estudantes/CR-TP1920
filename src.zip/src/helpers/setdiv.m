function [offset] = setdiv(offsetOriginal)
    offset =  offsetOriginal / 3;
end