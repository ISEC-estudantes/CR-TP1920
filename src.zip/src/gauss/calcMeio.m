function [meio] = calcMeio(baixo , alto)
    meio = (alto - baixo)/2  + baixo;
end

