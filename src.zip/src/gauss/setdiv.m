function [oofset] = setdiv(offsetOriginal)
    oofset =  offsetOriginal / 3;
end